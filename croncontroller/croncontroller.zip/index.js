
exports.handler = async (event,env)=>{

    return {
        url:event.url,
    }

}